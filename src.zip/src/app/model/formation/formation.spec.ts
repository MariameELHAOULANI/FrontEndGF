import { FormationModel } from './formation';

describe('Message', () => {
  it('should create an instance', () => {
    //expect(new UserModel()).toBeTruthy();
  });
});
