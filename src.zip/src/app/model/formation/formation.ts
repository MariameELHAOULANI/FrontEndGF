export class FormationModel {
    id: number;
    formationTitle: string = '';
    objectifs: string = '';
    preRequis: string = '';
    etabli: string = '';
    nombreMax: number = 0;

    constructor(){
        
    }


}