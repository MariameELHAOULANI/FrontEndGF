export class UserModel {
    firstName: string;
    lastName: string;
    isFormateur: boolean;
    email: string;
    userName: string;
    password: string;


    constructor() {
    }
}