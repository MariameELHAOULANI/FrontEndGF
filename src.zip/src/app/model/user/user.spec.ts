import { UserModel } from './user';

describe('Message', () => {
  it('should create an instance', () => {
    //expect(new UserModel()).toBeTruthy();
  });
});
