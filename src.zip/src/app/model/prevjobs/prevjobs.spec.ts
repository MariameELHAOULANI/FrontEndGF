import { PrevjobsModel } from './prevjobs';

describe('Message', () => {
  it('should create an instance', () => {
    //expect(new PlanformationModel()).toBeTruthy();
  });
});