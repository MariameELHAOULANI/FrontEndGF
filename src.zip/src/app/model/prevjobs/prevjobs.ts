
export class PrevjobsModel { 
  formateurId: number = 0;
  jobTitle: string = '';
  jobDesc: string = '';
  company: string = '';
  activities: string = '';
  startDate: Date =new Date() ;
  endDate:Date=new Date();

  constructor(){

  }
}
