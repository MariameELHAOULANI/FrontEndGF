export class PlanformationModel { 
  formationId: number = 0;
  taskName: string = '';
  details: string = '';
  duration: number = 0;
  prix: number = 0;

  constructor(){

  }
 }
