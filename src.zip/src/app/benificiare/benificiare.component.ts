import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-benificiare',
  templateUrl: './benificiare.component.html',
  styleUrls: ['./benificiare.component.css']
})
export class BenificiareComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
